/* ===== Receitas de Natal — JS simples (para avaliação) =====
   - Destaca item ativo no menu
   - Toggle dos ingredientes (botão + / -)
   - Atalho para imprimir (window.print)
*/

(function () {
  function currentFile() {
    const path = window.location.pathname;
    const file = path.split("/").pop() || "index.htm";
    // em alguns hosts pode vir vazio ou com querystring
    return file.split("?")[0].split("#")[0];
  }

  // Marca link ativo no menu
  const file = currentFile();
  document.querySelectorAll(".nav-links a").forEach((a) => {
    const href = (a.getAttribute("href") || "").split("?")[0];
    if (href === file) a.classList.add("active");
  });

  // Se existirem botões de imprimir, liga-os
  document.querySelectorAll("[data-print]").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      window.print();
    });
  });
})();

// Toggle dos ingredientes — usado pelas páginas de receita (onclick no HTML)
function toggleIngredients(id) {
  const box = document.getElementById(id);
  if (!box) return;

  const btn = document.querySelector(".toggle-btn");
  const icon = btn ? btn.querySelector(".toggle-icon") : null;
  const text = btn ? btn.querySelector(".toggle-text") : null;

  const isHidden = box.style.display === "none" || getComputedStyle(box).display === "none";

  if (isHidden) {
    box.style.display = "block";
    if (icon) icon.textContent = "−";
    if (text) text.textContent = "Ocultar ingredientes";
    // garante que o utilizador vê o resultado do clique
    box.scrollIntoView({ behavior: "smooth", block: "start" });
  } else {
    box.style.display = "none";
    if (icon) icon.textContent = "+";
    if (text) text.textContent = "Mostrar ingredientes";
  }
}
